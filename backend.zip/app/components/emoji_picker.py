import reflex as rx
from app.states.collections import CollectionsState


# Common emoji categories - simplified for better performance
EMOJI_CATEGORIES = {
    "Smileys & Emotion": ["😀", "😃", "😄", "😁", "😆", "😅", "🤣", "😂", "🙂", "🙃", "😉", "😊", "😇", "🥰", "😍", "🤩", "😘", "😗", "😚", "😙", "😋", "😛", "😜", "🤪", "😝", "🤑", "🤗", "🤭", "🤫", "🤔", "🤐", "🤨", "😐", "😑", "😶", "😏", "😒", "🙄", "😬", "🤥", "😌", "😔", "😪", "🤤", "😴", "😷", "🤒", "🤕", "🤢", "🤮", "🤧", "🥵", "🥶", "😵", "🤯", "🤠", "🥳", "😎", "🤓", "🧐"],
    "Objects": ["⌚", "📱", "📲", "💻", "⌨️", "🖥️", "🖨️", "🖱️", "🖲️", "🕹️", "💾", "💿", "📀", "📷", "📸", "📹", "🎥", "📞", "☎️", "📺", "📻", "🎙️", "⏰", "🕰️", "⌛", "⏳", "📡", "🔋", "🔌", "💡", "🔦", "🕯️", "🧯", "💸", "💵", "💴", "💶", "💷", "💰", "💳", "💎", "⚖️", "🧰", "🪛", "🔧", "🔨", "🛠️", "⛏️", "🔩", "⚙️", "🧱", "⛓️", "🧲", "💣", "🧨", "🪓", "🔪", "🗡️", "⚔️", "🛡️", "🔮", "📿", "🧿", "💈", "⚗️", "🔭", "🔬", "🕳️", "🩹", "🩺", "💊", "💉", "🩸", "🧬", "🦠", "🧫", "🧪", "🌡️", "🧹", "🪠", "🧺", "🧻", "🚽", "🚰", "🚿", "🛁", "🛀", "🧼", "🪒", "🧽", "🪣", "🧴", "🛎️", "🔑", "🗝️", "🚪", "🪑", "🛋️", "🛏️", "🛌", "🧸", "🖼️", "🪞", "🪟", "🛍️", "🛒", "🎁", "🎈", "🎏", "🎀", "🪄", "🪅", "🎊", "🎉", "🎎", "🏮", "🎐", "🧧", "✉️", "📩", "📨", "📧", "💌", "📥", "📤", "📦", "🪧", "📪", "📫", "📬", "📭", "📮", "📯", "📜", "📃", "📄", "📑", "🧾", "📊", "📈", "📉", "🗒️", "🗓️", "📆", "📅", "🗑️", "📇", "🗃️", "🗳️", "🗄️", "📋", "📁", "📂", "🗂️", "📓", "📔", "📒", "📕", "📗", "📘", "📙", "📚", "📖", "🔖", "🧷", "🔗", "📎", "🖇️", "📐", "📏", "🧮", "📌", "📍", "✂️", "🖊️", "🖋️", "✒️", "🖌️", "🖍️", "📝", "✏️", "🔍", "🔎", "🔏", "🔐", "🔒", "🔓"],
    "Symbols": ["❤️", "🧡", "💛", "💚", "💙", "💜", "🖤", "🤍", "🤎", "💔", "❣️", "💕", "💞", "💓", "💗", "💖", "💘", "💝", "💟", "☮️", "✝️", "☪️", "🕉️", "☸️", "🕎", "🔯", "🪯", "🛐", "⛎", "♈", "♉", "♊", "♋", "♌", "♍", "♎", "♏", "♐", "♑", "♒", "♓", "🆔", "⚛️", "🉑", "☢️", "☣️", "📴", "📳", "🈶", "🈚", "🈸", "🈺", "🈷️", "✴️", "🆚", "💮", "🉐", "㊙️", "㊗️", "🈴", "🈵", "🈹", "🈲", "🅰️", "🅱️", "🆎", "🆑", "🅾️", "🆘", "❌", "⭕", "🛑", "⛔", "📛", "🚫", "💯", "💢", "♨️", "🚷", "🚯", "🚳", "🚱", "🔞", "📵", "🚭", "❗", "❓", "❕", "❔", "‼️", "⁉️", "🔅", "🔆", "〽️", "⚠️", "🚸", "🔱", "⚜️", "🔰", "♻️", "✅", "🈯", "💹", "❇️", "✳️", "❎", "🌐", "💠", "Ⓜ️", "🌀", "💤", "🏧", "🚾", "♿", "🅿️", "🈳", "🈂️", "🛂", "🛃", "🛄", "🛅", "🚹", "🚺", "🚼", "🚻", "🚮", "🎦", "📶", "🈁", "🔣", "ℹ️", "🔤", "🔡", "🔠", "🔢", "🔟", "#️⃣", "*️⃣", "0️⃣", "1️⃣", "2️⃣", "3️⃣", "4️⃣", "5️⃣", "6️⃣", "7️⃣", "8️⃣", "9️⃣", "🔟", "🔺", "🔻", "💱", "💲"],
}




def emoji_picker() -> rx.Component:
    """Emoji picker component."""
    return rx.cond(
        CollectionsState.show_emoji_picker,
        rx.el.div(
            # Click outside overlay
            rx.el.div(
                on_click=CollectionsState.toggle_emoji_picker,
                class_name="fixed inset-0 z-40",
                style={"zIndex": 999},
            ),
            # Emoji picker panel
            rx.el.div(
                # Search input
                rx.el.input(
                    type="text",
                    placeholder="Search Emojis",
                    value=CollectionsState.emoji_search_query,
                    on_change=CollectionsState.set_emoji_search_query,
                    class_name="w-full px-3 py-2 mb-3 border border-gray-700 rounded-md text-white placeholder-gray-400 focus:outline-none focus:ring-1 focus:ring-green-500 text-sm",
                    style={"backgroundColor": "rgb(23, 23, 25)"},
                ),
                # Category tabs
                rx.el.div(
                    rx.foreach(
                        list(EMOJI_CATEGORIES.keys()),
                        lambda category: rx.el.button(
                            category,
                            on_click=CollectionsState.set_emoji_category(category),
                            class_name=rx.cond(
                                CollectionsState.emoji_selected_category == category,
                                "px-3 py-1 text-sm text-white border-b-2 border-green-500 transition-colors",
                                "px-3 py-1 text-sm text-gray-400 hover:text-white border-b-2 border-transparent hover:border-green-500 transition-colors",
                            ),
                        ),
                    ),
                    class_name="flex space-x-4 mb-3 overflow-x-auto",
                ),
                # Emoji grid
                rx.el.div(
                    rx.foreach(
                        CollectionsState.current_emoji_list,
                        lambda emoji: rx.el.button(
                            emoji,
                            on_click=CollectionsState.set_collection_emoji(emoji),
                            class_name="w-8 h-8 text-xl hover:bg-gray-700 rounded transition-colors flex items-center justify-center",
                        ),
                    ),
                    class_name="grid grid-cols-8 gap-1 max-h-64 overflow-y-auto",
                ),
                class_name="absolute top-full left-0 mt-2 w-80 border border-gray-700 rounded-lg shadow-xl p-4 z-50",
                style={"maxHeight": "400px", "zIndex": 1000, "backgroundColor": "rgb(23, 23, 25)"},
            ),
            class_name="relative",
        ),
    )

