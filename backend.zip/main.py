def main():
    print("Hello from rebase-platform-reflex!")


if __name__ == "__main__":
    main()
