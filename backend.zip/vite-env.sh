#!/bin/bash
# Environment variables for Vite
export HOST=0.0.0.0
export VITE_HOST=0.0.0.0
export HOSTNAME=0.0.0.0
