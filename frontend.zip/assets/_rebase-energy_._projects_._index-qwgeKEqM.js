import{r as e}from"./rolldown-runtime-C0ekFeFR.js";import{t}from"./react-_fSQ1luH.js";import"./react-dom-WI0eSuGp.js";import{A as n}from"./chunk-WWGJGFF6-IY8OznsJ.js";import{f as r,i,p as a}from"./context-CmfKudM3.js";import{n as o}from"./emotion-react.browser.esm-DMI4z_Bc.js";import"./esm-COAZHF5X.js";import{t as s}from"./search-Twg0BSaN.js";import{A as c,D as l,E as u,L as d,O as f,P as p,S as m,T as h,_ as g,a as _,b as v,c as y,g as b,h as x,j as S,k as C,m as w,n as T,t as E,u as D,v as O,w as k,x as A,y as j}from"./stateful_components-CJDPesBH.js";import{t as M}from"./esm-CnE9PTDd.js";var N=e(t(),1);function P(){let e=(0,N.useContext)(i.reflex___state____state__app___states___collections____collections_state),t=(0,N.useRef)(null);return a.ref_chart_reflex_Var_422515875334651992_reflex_Var_card_rx_state__id_=t,o(`div`,{className:e.timeseries_card_columns_rx_state_?.valueOf?.()===1?.valueOf?.()?`grid grid-cols-1 gap-6`:`grid grid-cols-2 gap-6`},Array.prototype.map.call(e.esett_card_data_rx_state_??[],(e,n)=>o(`div`,{className:`rounded-lg border border-gray-700`,css:{backgroundColor:`rgb(23,23,25)`},key:n},o(`div`,{className:`p-4 border-b border-gray-700`},o(`h3`,{className:`text-white font-bold text-lg`},e?.name)),o(`div`,{className:`pb-4 pt-2`},o(`div`,{className:`mx-4 rounded-lg overflow-hidden`,css:{backgroundColor:`rgb(23,23,25)`}},o(M,{css:{height:`250px`,width:`100%`},id:`chart-`+e?.id,option:{backgroundColor:`rgb(23,23,25)`,grid:{left:`0%`,right:`5%`,top:`50px`,bottom:`20px`,containLabel:!1,backgroundColor:`rgb(23,23,25)`},xAxis:{type:`category`,data:`Thu 01/01.Thu 01/01.Thu 01/01.Thu 01/01.Thu 01/01.Thu 01/01.Thu 01/01.Thu 01/01.Thu 01/01.Thu 01/01.Fri 02/01.Fri 02/01.Fri 02/01.Fri 02/01.Fri 02/01.Fri 02/01.Fri 02/01.Fri 02/01.Fri 02/01.Fri 02/01.Fri 02/01.Fri 02/01.Fri 02/01.Fri 02/01.Fri 02/01.Fri 02/01.Fri 02/01.Fri 02/01.Fri 02/01.Fri 02/01.Fri 02/01.Fri 02/01.Fri 02/01.Fri 02/01.Sat 03/01.Sat 03/01.Sat 03/01.Sat 03/01.Sat 03/01.Sat 03/01.Sat 03/01.Sat 03/01.Sat 03/01.Sat 03/01.Sat 03/01.Sat 03/01.Sat 03/01.Sat 03/01.Sat 03/01.Sat 03/01.Sat 03/01.Sat 03/01.Sat 03/01.Sat 03/01.Sat 03/01.Sat 03/01.Sat 03/01.Sat 03/01.Sun 04/01.Sun 04/01.Sun 04/01.Sun 04/01.Sun 04/01.Sun 04/01.Sun 04/01.Sun 04/01.Sun 04/01.Sun 04/01.Sun 04/01.Sun 04/01.Sun 04/01.Sun 04/01.Sun 04/01.Sun 04/01.Sun 04/01.Sun 04/01.Sun 04/01.Sun 04/01.Sun 04/01.Sun 04/01.Sun 04/01.Sun 04/01.Mon 05/01.Mon 05/01.Mon 05/01.Mon 05/01.Mon 05/01.Mon 05/01.Mon 05/01.Mon 05/01.Mon 05/01.Mon 05/01.Mon 05/01.Mon 05/01.Mon 05/01.Mon 05/01.Mon 05/01.Mon 05/01.Mon 05/01.Mon 05/01.Mon 05/01.Mon 05/01.Mon 05/01.Mon 05/01.Mon 05/01.Mon 05/01.Tue 06/01.Tue 06/01.Tue 06/01.Tue 06/01.Tue 06/01.Tue 06/01.Tue 06/01.Tue 06/01.Tue 06/01.Tue 06/01.Tue 06/01.Tue 06/01.Tue 06/01.Tue 06/01.Tue 06/01`.split(`.`),axisLine:{show:!1},axisTick:{show:!1},axisLabel:{color:`#9ca3af`,fontSize:10,margin:8,rotate:0,interval:`auto`,showMinLabel:!0,showMaxLabel:!0},splitLine:{show:!0,lineStyle:{color:`#374151`,type:`solid`,opacity:.3}},boundaryGap:!1},yAxis:{type:`value`,axisLine:{show:!1},axisTick:{show:!1},axisLabel:{color:`#9ca3af`,fontSize:10,margin:8,show:!0},splitLine:{show:!0,lineStyle:{color:`#374151`,type:`solid`}},show:!0},tooltip:{trigger:`axis`,backgroundColor:`rgb(23,23,25)`,borderColor:`#374151`,borderWidth:1,textStyle:{color:`#e5e7eb`},axisPointer:{type:`line`}},legend:{show:!0,top:`10px`,right:`20px`,orient:`horizontal`,itemGap:16,textStyle:{color:`#9ca3af`,fontSize:10},selectedMode:!0,data:[{name:`Actual`,icon:`circle`,itemStyle:{color:`#f97316`}},{name:`Forecast`,icon:`circle`,itemStyle:{color:`#22c55e`}}],itemWidth:10,itemHeight:10},animation:!1,series:[{name:`Actual`,type:`line`,data:[78.62437537528962,70.95785513003258,72.00258208183304,82.9539572402091,75.91827960128961,85.00383271628881,90.2,90.2,90.2,90.2,67.81430108353145,69.9520291171496,74.02276030406115,79.44272075029414,78.26834476565314,72.96359527933461,82.06968809694709,77.76278003038775,85.29239863436437,90.2,84.33681705056291,88.00194855726434,68.48394229825922,69.63224066368963,69.94983003563672,66.4004203632683,75.82570514529246,87.19286809701893,73.73593613065921,75.09624468800905,79.85724932899342,84.82035548725496,86.4611169571918,90.2,67.78383235205374,66.90874012211492,65.22191867255334,65.95651870200464,81.81328435852613,72.19780399875758,79.51499634487101,83.45809124007016,88.15853496386431,90.2,90.2,87.96653237579847,62.00531312929622,65.50347930382256,69.12326197873949,78.53205096257568,77.22255416323137,80.58456625621213,85.4128746374815,75.05597503613924,82.58010400075602,90.05721393735631,89.09994349310595,90.2,65.2071120629731,68.53610440324033,63.8135970738229,67.7055223661084,67.81852700892887,71.01817292119473,80.49545214159241,86.72609042760982,79.05830338640828,84.107249040161,90.2,87.48747488932594,62.27883747221695,76.00269004359464,72.65300734215432,80.1835376483853,78.15836837757135,81.4157086843511,87.48730894628598,79.02647377864442,83.16744959238142,88.67487062723778,83.0585348692032,90.2,63.75748692118652,64.15596288865208,80.98439055399703,68.18774498398408,73.90670859382226,78.71430196084764,79.4690517581978,86.15692921473902,90.2,86.98960585490656,88.9071451901969,90.2,76.34978502279317,76.13072118168516,64.36849521922116,71.94590331524057,85.38594363877132,77.26878587884511,84.74495735967436,90.2,77.01607595305718,90.2,81.36972770049617,85.33625112754233,67.56685443164949,69.34773529754395,80.26976597012231,71.84207726181732,84.10343861566821,83.61272178317738,81.45172634533837,87.38070746776931,90.2,84.54931261366181,90.2,86.61359624439001,65.56417240472584,74.93931296893321,72.45750091133323],lineStyle:{color:`#f97316`,width:2},symbol:`none`,smooth:!0},{name:`Forecast`,type:`line`,data:[85.85331877326269,69.8950636138517,68.2548962662886,80.73845540665727,73.05403694633466,90.2,90.2,90.2,86.84052867928357,87.61284711531586,69.33923175491437,62.99023274787001,75.34030859912912,76.756118993377,74.07852438550395,79.39350584807406,87.54407361125958,85.31313553430768,90.01175884623474,90.2,80.67715772563177,90.2,66.54333187931972,68.56533833510262,76.69641414723341,72.21695887019038,75.71826975649181,85.74738742474128,68.79038939892595,81.99705600736009,76.80598890952248,78.33251930620641,87.61256834638404,86.30887229057956,63.86926835877321,64.2955197440689,70.38354767764704,64.01872139148648,77.41856241602326,72.46733196656774,71.57248124388663,87.57984324051503,84.55182786956479,90.2,84.79120756731851,89.32029592678931,59.40721835192848,69.04477807007791,74.7865433566876,80.95837359953187,73.94793881055314,83.1150715421093,80.88111943848108,72.61618334901222,75.90312689325626,90.2,90.2,90.2,61.12254071743999,74.15488289422804,62.58763890572399,65.13551785851959,67.26952261127188,73.54860380194305,87.18113173846139,80.9858855280986,82.96668467769263,77.09155168269302,90.2,90.2,60.022220704886806,78.39073156099253,68.02484699805918,75.9283642463142,71.56502883644842,76.60721839925941,85.43877615773043,80.33293030674247,77.11130715797212,87.3254895074347,86.32430271288511,90.2,63.39817125410669,68.06439874285407,78.17653344114578,70.26555836366586,78.97864245567185,74.28905135997408,77.39477607434894,90.2,86.37175308798903,78.56473079854605,84.59910723292435,89.59596789191271,74.65044119664284,77.14449757290807,70.62997205980916,69.07788225496563,80.74693220145794,82.35154440181073,78.48921780511378,90.2,70.4248151004513,90.2,86.5901451985917,85.42281557368062,61.136960296634506,72.74212740008589,73.19453120961371,76.93372025318489,90.2,77.44571994443054,74.86082385375133,84.05906828562469,86.1966208949722,90.2,90.2,89.39672402526784,70.08520879294964,80.58078615817475,78.0157302085576],lineStyle:{color:`#22c55e`,width:2},symbol:`none`,smooth:!0},{name:`_nowLine`,type:`line`,data:[],markLine:{silent:!0,symbol:`none`,label:{show:!1},animation:!1,lineStyle:{color:`#dc2626`,width:1,type:`dashed`},data:[{xAxis:24}]},legendHoverLink:!1}]},ref:t}),o(`script`,{},`
                    (function() {
                        const fullTimes = ["Thu 01/01 14:08", "Thu 01/01 15:08", "Thu 01/01 16:08", "Thu 01/01 17:08", "Thu 01/01 18:08", "Thu 01/01 19:08", "Thu 01/01 20:08", "Thu 01/01 21:08", "Thu 01/01 22:08", "Thu 01/01 23:08", "Fri 02/01 00:08", "Fri 02/01 01:08", "Fri 02/01 02:08", "Fri 02/01 03:08", "Fri 02/01 04:08", "Fri 02/01 05:08", "Fri 02/01 06:08", "Fri 02/01 07:08", "Fri 02/01 08:08", "Fri 02/01 09:08", "Fri 02/01 10:08", "Fri 02/01 11:08", "Fri 02/01 12:08", "Fri 02/01 13:08", "Fri 02/01 14:08", "Fri 02/01 15:08", "Fri 02/01 16:08", "Fri 02/01 17:08", "Fri 02/01 18:08", "Fri 02/01 19:08", "Fri 02/01 20:08", "Fri 02/01 21:08", "Fri 02/01 22:08", "Fri 02/01 23:08", "Sat 03/01 00:08", "Sat 03/01 01:08", "Sat 03/01 02:08", "Sat 03/01 03:08", "Sat 03/01 04:08", "Sat 03/01 05:08", "Sat 03/01 06:08", "Sat 03/01 07:08", "Sat 03/01 08:08", "Sat 03/01 09:08", "Sat 03/01 10:08", "Sat 03/01 11:08", "Sat 03/01 12:08", "Sat 03/01 13:08", "Sat 03/01 14:08", "Sat 03/01 15:08", "Sat 03/01 16:08", "Sat 03/01 17:08", "Sat 03/01 18:08", "Sat 03/01 19:08", "Sat 03/01 20:08", "Sat 03/01 21:08", "Sat 03/01 22:08", "Sat 03/01 23:08", "Sun 04/01 00:08", "Sun 04/01 01:08", "Sun 04/01 02:08", "Sun 04/01 03:08", "Sun 04/01 04:08", "Sun 04/01 05:08", "Sun 04/01 06:08", "Sun 04/01 07:08", "Sun 04/01 08:08", "Sun 04/01 09:08", "Sun 04/01 10:08", "Sun 04/01 11:08", "Sun 04/01 12:08", "Sun 04/01 13:08", "Sun 04/01 14:08", "Sun 04/01 15:08", "Sun 04/01 16:08", "Sun 04/01 17:08", "Sun 04/01 18:08", "Sun 04/01 19:08", "Sun 04/01 20:08", "Sun 04/01 21:08", "Sun 04/01 22:08", "Sun 04/01 23:08", "Mon 05/01 00:08", "Mon 05/01 01:08", "Mon 05/01 02:08", "Mon 05/01 03:08", "Mon 05/01 04:08", "Mon 05/01 05:08", "Mon 05/01 06:08", "Mon 05/01 07:08", "Mon 05/01 08:08", "Mon 05/01 09:08", "Mon 05/01 10:08", "Mon 05/01 11:08", "Mon 05/01 12:08", "Mon 05/01 13:08", "Mon 05/01 14:08", "Mon 05/01 15:08", "Mon 05/01 16:08", "Mon 05/01 17:08", "Mon 05/01 18:08", "Mon 05/01 19:08", "Mon 05/01 20:08", "Mon 05/01 21:08", "Mon 05/01 22:08", "Mon 05/01 23:08", "Tue 06/01 00:08", "Tue 06/01 01:08", "Tue 06/01 02:08", "Tue 06/01 03:08", "Tue 06/01 04:08", "Tue 06/01 05:08", "Tue 06/01 06:08", "Tue 06/01 07:08", "Tue 06/01 08:08", "Tue 06/01 09:08", "Tue 06/01 10:08", "Tue 06/01 11:08", "Tue 06/01 12:08", "Tue 06/01 13:08", "Tue 06/01 14:08"];
                        const chartId = 'chart-`+e?.id+`';
                        
                        function setupTooltipFormatter() {
                            const chartContainer = document.getElementById(chartId);
                            if (!chartContainer) return false;
                            
                            // Get ECharts instance
                            if (typeof echarts === 'undefined') return false;
                            
                            const chartInstance = echarts.getInstanceByDom(chartContainer);
                            if (!chartInstance) return false;
                            
                            // Set tooltip formatter directly
                            chartInstance.setOption({
                                tooltip: {
                                    formatter: function(params) {
                                        if (!params || params.length === 0) return '';
                                        const param = params[0];
                                        let result = '';
                                        
                                        // Get the data index
                                        const dataIndex = param.dataIndex;
                                        let dateStr = param.axisValue || '';
                                        
                                        // Add timestamp if available
                                        if (dataIndex >= 0 && fullTimes && fullTimes[dataIndex]) {
                                            const fullTime = fullTimes[dataIndex];
                                            const timeParts = fullTime.split(' ');
                                            if (timeParts.length >= 3) {
                                                const timestamp = timeParts[2];
                                                // Check if timestamp is already in dateStr
                                                if (dateStr.indexOf(timestamp) === -1) {
                                                    dateStr = dateStr + ' ' + timestamp;
                                                }
                                            }
                                        }
                                        
                                        result = dateStr + '<br/>';
                                        
                                        // Format each series value to exactly 2 decimal places
                                        params.forEach(function(item) {
                                            if (item.seriesName !== 'now') {
                                                const numValue = typeof item.value === 'number' ? item.value : parseFloat(item.value);
                                                const value = isNaN(numValue) ? item.value : numValue.toFixed(2);
                                                result += '<span style="display:inline-block;margin-right:5px;width:10px;height:10px;border-radius:50%;background-color:' + item.color + ';"></span>';
                                                result += item.seriesName + ': <span style="float:right;margin-left:20px;text-align:right;min-width:50px;">' + value + '</span><br/>';
                                            }
                                        });
                                        
                                        return result;
                                    }
                                }
                            }, false);
                            
                            return true;
                        }
                        
                        // Try multiple times to set up formatter
                        let attempts = 0;
                        const maxAttempts = 10;
                        const interval = setInterval(function() {
                            if (setupTooltipFormatter() || attempts >= maxAttempts) {
                                clearInterval(interval);
                            }
                            attempts++;
                        }, 100);
                        
                        // Also try immediately
                        setTimeout(setupTooltipFormatter, 50);
                    })();
                    `))))))}function F(){return o(N.Fragment,{},(0,N.useContext)(i.reflex___state____state__app___states___collections____collections_state).active_collection_view_type_rx_state_?.valueOf?.()===`time_series_cards`?.valueOf?.()?o(N.Fragment,{},o(`div`,{className:`w-full`},o(N.Fragment,{},o(N.Fragment,{},o(`div`,{className:`mb-4`},o(y,{})))),o(P,{}))):o(N.Fragment,{},o(`div`,{className:`w-full`},o(`div`,{className:`mb-4`},o(`div`,{className:`flex items-center space-x-3`},o(`div`,{className:`relative`},o(s,{className:`absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-gray-400`}),o(S,{})),o(`div`,{className:`w-px h-6 bg-gray-700`}),o(T,{}),o(_,{}))),o(`div`,{className:`w-full`},o(p,{}),o(`div`,{className:`border border-gray-700 rounded-lg overflow-hidden relative`,css:{backgroundColor:`rgb(23, 23, 25)`},"data-table-container":`true`},o(`script`,{},`
                window.initColumnResizecolumn_resize_input_collection = function() {
                    document.querySelectorAll('.resize-handle-collection').forEach(function(handle) {
                        const newHandle = handle.cloneNode(true);
                        handle.parentNode.replaceChild(newHandle, handle);
                        
                        newHandle.addEventListener('mousedown', function(e) {
                            e.preventDefault();
                            e.stopPropagation();
                            
                            const columnKey = newHandle.getAttribute('data-column-key');
                            const tableContainer = newHandle.closest('[data-table-container]');
                            if (!tableContainer) return;
                            
                            const headerCells = tableContainer.querySelectorAll('[data-column-header="' + columnKey + '"]');
                            const dataCells = tableContainer.querySelectorAll('[data-column="' + columnKey + '"]');
                            
                            if (headerCells.length === 0) return;
                            
                            const firstHeaderCell = headerCells[0];
                            const startX = e.clientX;
                            const startWidth = parseInt(window.getComputedStyle(firstHeaderCell).width, 10);
                            
                            const handleRect = newHandle.getBoundingClientRect();
                            const containerRect = tableContainer.getBoundingClientRect();
                            const startHandleLeft = handleRect.left - containerRect.left;
                            
                            function onMouseMove(e) {
                                const diff = e.clientX - startX;
                                const newWidth = Math.max(50, startWidth + diff);
                                
                                headerCells.forEach(function(cell) {
                                    cell.style.width = newWidth + 'px';
                                    cell.style.minWidth = newWidth + 'px';
                                    cell.style.maxWidth = newWidth + 'px';
                                });
                                
                                dataCells.forEach(function(cell) {
                                    cell.style.width = newWidth + 'px';
                                    cell.style.minWidth = newWidth + 'px';
                                    cell.style.maxWidth = newWidth + 'px';
                                });
                                
                                const newHandleLeft = startHandleLeft + diff;
                                newHandle.style.left = (newHandleLeft - 2) + 'px';
                                
                                const allHandles = Array.from(tableContainer.querySelectorAll('.resize-handle-collection'));
                                const currentIndex = allHandles.indexOf(newHandle);
                                const allHeaders = Array.from(tableContainer.querySelectorAll('[data-column-header]'));
                                
                                let cumulativeWidth = 0;
                                allHeaders.forEach(function(headerCell) {
                                    const key = headerCell.getAttribute('data-column-header');
                                    let width = (key === columnKey) ? newWidth : parseInt(window.getComputedStyle(headerCell).width, 10);
                                    cumulativeWidth += width;
                                    
                                    const handleForColumn = allHandles.find(function(h) {
                                        return h.getAttribute('data-column-key') === key;
                                    });
                                    
                                    if (handleForColumn && allHandles.indexOf(handleForColumn) > currentIndex) {
                                        handleForColumn.style.left = (cumulativeWidth - 2) + 'px';
                                    }
                                });
                            }
                            
                            function onMouseUp(e) {
                                const diff = e.clientX - startX;
                                const newWidth = Math.max(50, startWidth + diff);
                                
                                const input = document.getElementById('column-resize-input-collection');
                                if (input) {
                                    input.value = columnKey + ':' + newWidth;
                                    const event = new Event('change', { bubbles: true });
                                    input.dispatchEvent(event);
                                }
                                
                                document.removeEventListener('mousemove', onMouseMove);
                                document.removeEventListener('mouseup', onMouseUp);
                                document.body.style.cursor = '';
                                document.body.style.userSelect = '';
                            }
                            
                            document.body.style.cursor = 'col-resize';
                            document.body.style.userSelect = 'none';
                            document.addEventListener('mousemove', onMouseMove);
                            document.addEventListener('mouseup', onMouseUp);
                        });
                    });
                };
                
                if (document.readyState === 'loading') {
                    document.addEventListener('DOMContentLoaded', function() {
                        setTimeout(window.initColumnResizecolumn_resize_input_collection, 100);
                    });
                } else {
                    setTimeout(window.initColumnResizecolumn_resize_input_collection, 100);
                }
                
                const observer = new MutationObserver(function() {
                    setTimeout(window.initColumnResizecolumn_resize_input_collection, 150);
                });
                observer.observe(document.body, { childList: true, subtree: true });
                `),o(`div`,{className:`flex border-b border-gray-700 group relative`,css:{backgroundColor:`rgb(23, 23, 25)`}},o(O,{}),o(v,{}),o(w,{}),o(A,{}),o(m,{}),o(k,{})),o(`div`,{className:`absolute inset-0`,css:{zIndex:50,pointerEvents:`none`}},o(x,{}),o(g,{}),o(D,{}),o(j,{}),o(h,{})),o(b,{}))))))}function I(){return o(N.Fragment,{},r((0,N.useContext)(i.reflex___state____state__app___states___collections____collections_state).active_collection_rx_state_)?o(N.Fragment,{},o(`div`,{},o(F,{}))):o(N.Fragment,{},o(`div`,{className:`flex items-center justify-center py-12`},o(`span`,{className:`text-gray-400 text-sm`},`No collection selected. Select a collection to get started.`))))}function L(){return o(N.Fragment,{},(0,N.useContext)(i.reflex___state____state__app___states___workspace____workspace_state).is_entity_route_rx_state_?o(l,{}):o(I,{}))}function R(){return o(N.Fragment,{},(0,N.useContext)(i.reflex___state____state__app___states___workspace____workspace_state).is_menu_route_rx_state_?o(N.Fragment,{},o(`div`,{className:`flex items-center justify-center py-12`},o(d,{}))):o(L,{}))}var z=n(function(){return o(N.Fragment,{},o(`div`,{className:`flex font-['Inter']`,css:{backgroundColor:`rgb(16, 16, 18)`}},o(E,{}),o(`div`,{className:`flex-1 h-screen overflow-y-auto`,css:{backgroundColor:`rgb(23, 23, 25)`}},o(`div`,{className:`flex items-center px-6 pt-6 pb-4`},o(c,{}),o(C,{})),o(`div`,{className:`px-6 pb-6`},o(R,{}))),o(`div`,{},o(u,{})),o(f,{})),o(`title`,{},`App | Projects`),o(`meta`,{content:`favicon.ico`,property:`og:image`}))});export{z as default};