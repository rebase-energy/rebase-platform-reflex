import{r as e}from"./rolldown-runtime-C0ekFeFR.js";import{t}from"./react-_fSQ1luH.js";import"./react-dom-WI0eSuGp.js";import{A as n}from"./chunk-WWGJGFF6-IY8OznsJ.js";import{f as r,i,p as a}from"./context-CmfKudM3.js";import{n as o}from"./emotion-react.browser.esm-DMI4z_Bc.js";import"./esm-COAZHF5X.js";import{t as s}from"./search-Twg0BSaN.js";import{A as c,D as l,E as u,L as d,O as f,P as p,S as m,T as h,_ as g,a as _,b as v,c as y,g as b,h as x,j as S,k as C,m as w,n as T,t as E,u as D,v as O,w as k,x as A,y as j}from"./stateful_components-CJDPesBH.js";import{t as M}from"./esm-CnE9PTDd.js";var N=e(t(),1);function P(){let e=(0,N.useContext)(i.reflex___state____state__app___states___collections____collections_state),t=(0,N.useRef)(null);return a.ref_chart_reflex_Var_422515875334651992_reflex_Var_card_rx_state__id_=t,o(`div`,{className:e.timeseries_card_columns_rx_state_?.valueOf?.()===1?.valueOf?.()?`grid grid-cols-1 gap-6`:`grid grid-cols-2 gap-6`},Array.prototype.map.call(e.esett_card_data_rx_state_??[],(e,n)=>o(`div`,{className:`rounded-lg border border-gray-700`,css:{backgroundColor:`rgb(23,23,25)`},key:n},o(`div`,{className:`p-4 border-b border-gray-700`},o(`h3`,{className:`text-white font-bold text-lg`},e?.name)),o(`div`,{className:`pb-4 pt-2`},o(`div`,{className:`mx-4 rounded-lg overflow-hidden`,css:{backgroundColor:`rgb(23,23,25)`}},o(M,{css:{height:`250px`,width:`100%`},id:`chart-`+e?.id,option:{backgroundColor:`rgb(23,23,25)`,grid:{left:`0%`,right:`5%`,top:`50px`,bottom:`20px`,containLabel:!1,backgroundColor:`rgb(23,23,25)`},xAxis:{type:`category`,data:`Thu 01/01.Thu 01/01.Thu 01/01.Thu 01/01.Thu 01/01.Thu 01/01.Thu 01/01.Thu 01/01.Thu 01/01.Thu 01/01.Fri 02/01.Fri 02/01.Fri 02/01.Fri 02/01.Fri 02/01.Fri 02/01.Fri 02/01.Fri 02/01.Fri 02/01.Fri 02/01.Fri 02/01.Fri 02/01.Fri 02/01.Fri 02/01.Fri 02/01.Fri 02/01.Fri 02/01.Fri 02/01.Fri 02/01.Fri 02/01.Fri 02/01.Fri 02/01.Fri 02/01.Fri 02/01.Sat 03/01.Sat 03/01.Sat 03/01.Sat 03/01.Sat 03/01.Sat 03/01.Sat 03/01.Sat 03/01.Sat 03/01.Sat 03/01.Sat 03/01.Sat 03/01.Sat 03/01.Sat 03/01.Sat 03/01.Sat 03/01.Sat 03/01.Sat 03/01.Sat 03/01.Sat 03/01.Sat 03/01.Sat 03/01.Sat 03/01.Sat 03/01.Sun 04/01.Sun 04/01.Sun 04/01.Sun 04/01.Sun 04/01.Sun 04/01.Sun 04/01.Sun 04/01.Sun 04/01.Sun 04/01.Sun 04/01.Sun 04/01.Sun 04/01.Sun 04/01.Sun 04/01.Sun 04/01.Sun 04/01.Sun 04/01.Sun 04/01.Sun 04/01.Sun 04/01.Sun 04/01.Sun 04/01.Sun 04/01.Mon 05/01.Mon 05/01.Mon 05/01.Mon 05/01.Mon 05/01.Mon 05/01.Mon 05/01.Mon 05/01.Mon 05/01.Mon 05/01.Mon 05/01.Mon 05/01.Mon 05/01.Mon 05/01.Mon 05/01.Mon 05/01.Mon 05/01.Mon 05/01.Mon 05/01.Mon 05/01.Mon 05/01.Mon 05/01.Mon 05/01.Mon 05/01.Tue 06/01.Tue 06/01.Tue 06/01.Tue 06/01.Tue 06/01.Tue 06/01.Tue 06/01.Tue 06/01.Tue 06/01.Tue 06/01.Tue 06/01.Tue 06/01.Tue 06/01.Tue 06/01.Tue 06/01`.split(`.`),axisLine:{show:!1},axisTick:{show:!1},axisLabel:{color:`#9ca3af`,fontSize:10,margin:8,rotate:0,interval:`auto`,showMinLabel:!0,showMaxLabel:!0},splitLine:{show:!0,lineStyle:{color:`#374151`,type:`solid`,opacity:.3}},boundaryGap:!1},yAxis:{type:`value`,axisLine:{show:!1},axisTick:{show:!1},axisLabel:{color:`#9ca3af`,fontSize:10,margin:8,show:!0},splitLine:{show:!0,lineStyle:{color:`#374151`,type:`solid`}},show:!0},tooltip:{trigger:`axis`,backgroundColor:`rgb(23,23,25)`,borderColor:`#374151`,borderWidth:1,textStyle:{color:`#e5e7eb`},axisPointer:{type:`line`}},legend:{show:!0,top:`10px`,right:`20px`,orient:`horizontal`,itemGap:16,textStyle:{color:`#9ca3af`,fontSize:10},selectedMode:!0,data:[{name:`Actual`,icon:`circle`,itemStyle:{color:`#f97316`}},{name:`Forecast`,icon:`circle`,itemStyle:{color:`#22c55e`}}],itemWidth:10,itemHeight:10},animation:!1,series:[{name:`Actual`,type:`line`,data:[65.74297213268034,66.20229952502547,71.02090155121121,80.91750552014483,73.17889450683496,89.92958541055198,85.01884816681284,88.8277173929203,88.92477693362643,90.2,67.93832630267057,70.37397516841528,63.487068740970486,79.44652552407132,77.60294252027099,75.14833657660691,76.31448187070822,83.13777875386073,81.0097554501608,79.8718327493953,90.2,84.19800125321653,66.67443261377561,67.49193649263722,75.00248767742085,75.96045145337061,79.88621548141938,85.7237848301331,74.54977486956481,75.66370394748047,81.16098037140847,82.02544219922692,90.2,90.2,73.65895649510455,61.215051356106585,76.73235821473376,76.01728616145354,79.18937425261419,72.17197518538083,72.2644477841578,89.35130345748917,78.36326367794263,81.00301916013426,86.31660408083144,89.30159813153195,70.23184888346566,64.23225130815467,78.17179438376438,68.30120251828298,78.1361836921762,81.15139471321051,87.29943121536351,77.36215604088184,90.2,82.42170625921624,90.2,90.2,73.30163191540572,64.01593434113425,76.54572170078363,72.59621583840702,78.91509275905062,85.48132040182699,74.80954566359847,88.13516634048084,90.2,89.43212098862698,90.2,88.22332145419409,63.41608088151211,66.79599331682957,70.05378171738133,80.78679704784497,71.31631264019204,74.00922597242798,88.94682744883326,82.02238018366296,79.58581351939735,90.2,81.37952849048449,90.2,67.73015098393124,78.9007854140192,75.66201794879336,71.06178473243605,68.92784321485331,75.16562883739816,75.84343183541222,85.65708759466267,90.16887671647038,90.2,90.2,88.45891807226138,74.77344294725717,62.09504238932857,66.93274965241646,70.98011772928578,71.8557911721964,72.38848966433348,77.64048677725091,75.53157736192952,78.84451102479522,87.9471925851631,90.2,90.2,66.62557612987011,74.48322924779845,66.74777126416545,75.21355340639337,78.55915331297814,77.06477242989051,73.41382328497478,80.96596595028961,90.2,86.29922652642603,89.02125114358579,90.2,65.03184112292655,75.27032885078208,78.64935937154439],lineStyle:{color:`#f97316`,width:2},symbol:`none`,smooth:!0},{name:`Forecast`,type:`line`,data:[64.9500690762581,67.38618316646753,64.115448737804,73.17692737887953,72.19685746139915,90.2,84.68711575601506,80.35213598194157,90.2,87.8920259012156,67.96159228336933,63.892533109584946,68.67762244039046,73.60115533300215,73.09157772602512,76.41697215255148,78.60762500759606,84.25905125629103,88.57178016486426,75.10166191358097,83.2648908724503,80.26785005906754,61.67247606312114,70.62920588701768,80.3546682138362,74.42298073967332,75.03806387494211,82.07433592335616,67.50956499673505,74.41947176371654,77.78158058484432,78.47406902437828,89.37195733790227,90.2,78.67283920106503,57.67866270177135,69.44542982731862,75.65757316843674,79.06755053024902,77.93414308401782,78.3584552622968,80.948096512632,74.94322656280501,75.88704233026522,81.55749602167836,90.2,68.78451338731666,61.86685731896387,70.39382268964087,71.51422501532448,82.47227938215019,82.97443234218079,90.2,82.13807865392567,90.2,82.4963045716486,90.2,90.2,66.26810950352673,65.06342853682692,76.63765844972083,69.61822053317879,71.43106127003973,84.91701801120526,80.93162986882251,84.37488552402137,87.7836869598871,90.2,90.2,90.2,61.98302388278686,70.62043074196326,65.3794489926909,79.79307701721513,76.50538195045426,78.81790478397862,81.06684358865994,81.61722084859468,82.09503006377388,90.2,75.78183052161818,85.13093264255448,69.33739929368878,81.94389995503857,76.42179762246086,78.09523145639082,62.238108586933826,70.83658751181514,80.76689697869082,87.386513981733,90.2,90.2,85.16790808996191,89.27421379873796,77.68327073318126,62.98698422059752,67.13721192685215,70.36777960262485,67.79559995943845,74.72788294402962,79.02109626556988,74.70253636040276,83.8862460040678,90.2,90.2,90.2,60.84591961877983,76.49153060065153,62.60486792079173,68.16658687396891,77.76048540770928,74.75474343359504,75.93381553549946,77.75660243977893,90.2,87.80367984926514,90.2,90.2,67.92819434734787,80.6309931685715,74.82703081938206],lineStyle:{color:`#22c55e`,width:2},symbol:`none`,smooth:!0},{name:`_nowLine`,type:`line`,data:[],markLine:{silent:!0,symbol:`none`,label:{show:!1},animation:!1,lineStyle:{color:`#dc2626`,width:1,type:`dashed`},data:[{xAxis:24}]},legendHoverLink:!1}]},ref:t}),o(`script`,{},`
                    (function() {
                        const fullTimes = ["Thu 01/01 14:08", "Thu 01/01 15:08", "Thu 01/01 16:08", "Thu 01/01 17:08", "Thu 01/01 18:08", "Thu 01/01 19:08", "Thu 01/01 20:08", "Thu 01/01 21:08", "Thu 01/01 22:08", "Thu 01/01 23:08", "Fri 02/01 00:08", "Fri 02/01 01:08", "Fri 02/01 02:08", "Fri 02/01 03:08", "Fri 02/01 04:08", "Fri 02/01 05:08", "Fri 02/01 06:08", "Fri 02/01 07:08", "Fri 02/01 08:08", "Fri 02/01 09:08", "Fri 02/01 10:08", "Fri 02/01 11:08", "Fri 02/01 12:08", "Fri 02/01 13:08", "Fri 02/01 14:08", "Fri 02/01 15:08", "Fri 02/01 16:08", "Fri 02/01 17:08", "Fri 02/01 18:08", "Fri 02/01 19:08", "Fri 02/01 20:08", "Fri 02/01 21:08", "Fri 02/01 22:08", "Fri 02/01 23:08", "Sat 03/01 00:08", "Sat 03/01 01:08", "Sat 03/01 02:08", "Sat 03/01 03:08", "Sat 03/01 04:08", "Sat 03/01 05:08", "Sat 03/01 06:08", "Sat 03/01 07:08", "Sat 03/01 08:08", "Sat 03/01 09:08", "Sat 03/01 10:08", "Sat 03/01 11:08", "Sat 03/01 12:08", "Sat 03/01 13:08", "Sat 03/01 14:08", "Sat 03/01 15:08", "Sat 03/01 16:08", "Sat 03/01 17:08", "Sat 03/01 18:08", "Sat 03/01 19:08", "Sat 03/01 20:08", "Sat 03/01 21:08", "Sat 03/01 22:08", "Sat 03/01 23:08", "Sun 04/01 00:08", "Sun 04/01 01:08", "Sun 04/01 02:08", "Sun 04/01 03:08", "Sun 04/01 04:08", "Sun 04/01 05:08", "Sun 04/01 06:08", "Sun 04/01 07:08", "Sun 04/01 08:08", "Sun 04/01 09:08", "Sun 04/01 10:08", "Sun 04/01 11:08", "Sun 04/01 12:08", "Sun 04/01 13:08", "Sun 04/01 14:08", "Sun 04/01 15:08", "Sun 04/01 16:08", "Sun 04/01 17:08", "Sun 04/01 18:08", "Sun 04/01 19:08", "Sun 04/01 20:08", "Sun 04/01 21:08", "Sun 04/01 22:08", "Sun 04/01 23:08", "Mon 05/01 00:08", "Mon 05/01 01:08", "Mon 05/01 02:08", "Mon 05/01 03:08", "Mon 05/01 04:08", "Mon 05/01 05:08", "Mon 05/01 06:08", "Mon 05/01 07:08", "Mon 05/01 08:08", "Mon 05/01 09:08", "Mon 05/01 10:08", "Mon 05/01 11:08", "Mon 05/01 12:08", "Mon 05/01 13:08", "Mon 05/01 14:08", "Mon 05/01 15:08", "Mon 05/01 16:08", "Mon 05/01 17:08", "Mon 05/01 18:08", "Mon 05/01 19:08", "Mon 05/01 20:08", "Mon 05/01 21:08", "Mon 05/01 22:08", "Mon 05/01 23:08", "Tue 06/01 00:08", "Tue 06/01 01:08", "Tue 06/01 02:08", "Tue 06/01 03:08", "Tue 06/01 04:08", "Tue 06/01 05:08", "Tue 06/01 06:08", "Tue 06/01 07:08", "Tue 06/01 08:08", "Tue 06/01 09:08", "Tue 06/01 10:08", "Tue 06/01 11:08", "Tue 06/01 12:08", "Tue 06/01 13:08", "Tue 06/01 14:08"];
                        const chartId = 'chart-`+e?.id+`';
                        
                        function setupTooltipFormatter() {
                            const chartContainer = document.getElementById(chartId);
                            if (!chartContainer) return false;
                            
                            // Get ECharts instance
                            if (typeof echarts === 'undefined') return false;
                            
                            const chartInstance = echarts.getInstanceByDom(chartContainer);
                            if (!chartInstance) return false;
                            
                            // Set tooltip formatter directly
                            chartInstance.setOption({
                                tooltip: {
                                    formatter: function(params) {
                                        if (!params || params.length === 0) return '';
                                        const param = params[0];
                                        let result = '';
                                        
                                        // Get the data index
                                        const dataIndex = param.dataIndex;
                                        let dateStr = param.axisValue || '';
                                        
                                        // Add timestamp if available
                                        if (dataIndex >= 0 && fullTimes && fullTimes[dataIndex]) {
                                            const fullTime = fullTimes[dataIndex];
                                            const timeParts = fullTime.split(' ');
                                            if (timeParts.length >= 3) {
                                                const timestamp = timeParts[2];
                                                // Check if timestamp is already in dateStr
                                                if (dateStr.indexOf(timestamp) === -1) {
                                                    dateStr = dateStr + ' ' + timestamp;
                                                }
                                            }
                                        }
                                        
                                        result = dateStr + '<br/>';
                                        
                                        // Format each series value to exactly 2 decimal places
                                        params.forEach(function(item) {
                                            if (item.seriesName !== 'now') {
                                                const numValue = typeof item.value === 'number' ? item.value : parseFloat(item.value);
                                                const value = isNaN(numValue) ? item.value : numValue.toFixed(2);
                                                result += '<span style="display:inline-block;margin-right:5px;width:10px;height:10px;border-radius:50%;background-color:' + item.color + ';"></span>';
                                                result += item.seriesName + ': <span style="float:right;margin-left:20px;text-align:right;min-width:50px;">' + value + '</span><br/>';
                                            }
                                        });
                                        
                                        return result;
                                    }
                                }
                            }, false);
                            
                            return true;
                        }
                        
                        // Try multiple times to set up formatter
                        let attempts = 0;
                        const maxAttempts = 10;
                        const interval = setInterval(function() {
                            if (setupTooltipFormatter() || attempts >= maxAttempts) {
                                clearInterval(interval);
                            }
                            attempts++;
                        }, 100);
                        
                        // Also try immediately
                        setTimeout(setupTooltipFormatter, 50);
                    })();
                    `))))))}function F(){return o(N.Fragment,{},(0,N.useContext)(i.reflex___state____state__app___states___collections____collections_state).active_collection_view_type_rx_state_?.valueOf?.()===`time_series_cards`?.valueOf?.()?o(N.Fragment,{},o(`div`,{className:`w-full`},o(N.Fragment,{},o(N.Fragment,{},o(`div`,{className:`mb-4`},o(y,{})))),o(P,{}))):o(N.Fragment,{},o(`div`,{className:`w-full`},o(`div`,{className:`mb-4`},o(`div`,{className:`flex items-center space-x-3`},o(`div`,{className:`relative`},o(s,{className:`absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-gray-400`}),o(S,{})),o(`div`,{className:`w-px h-6 bg-gray-700`}),o(T,{}),o(_,{}))),o(`div`,{className:`w-full`},o(p,{}),o(`div`,{className:`border border-gray-700 rounded-lg overflow-hidden relative`,css:{backgroundColor:`rgb(23, 23, 25)`},"data-table-container":`true`},o(`script`,{},`
                window.initColumnResizecolumn_resize_input_collection = function() {
                    document.querySelectorAll('.resize-handle-collection').forEach(function(handle) {
                        const newHandle = handle.cloneNode(true);
                        handle.parentNode.replaceChild(newHandle, handle);
                        
                        newHandle.addEventListener('mousedown', function(e) {
                            e.preventDefault();
                            e.stopPropagation();
                            
                            const columnKey = newHandle.getAttribute('data-column-key');
                            const tableContainer = newHandle.closest('[data-table-container]');
                            if (!tableContainer) return;
                            
                            const headerCells = tableContainer.querySelectorAll('[data-column-header="' + columnKey + '"]');
                            const dataCells = tableContainer.querySelectorAll('[data-column="' + columnKey + '"]');
                            
                            if (headerCells.length === 0) return;
                            
                            const firstHeaderCell = headerCells[0];
                            const startX = e.clientX;
                            const startWidth = parseInt(window.getComputedStyle(firstHeaderCell).width, 10);
                            
                            const handleRect = newHandle.getBoundingClientRect();
                            const containerRect = tableContainer.getBoundingClientRect();
                            const startHandleLeft = handleRect.left - containerRect.left;
                            
                            function onMouseMove(e) {
                                const diff = e.clientX - startX;
                                const newWidth = Math.max(50, startWidth + diff);
                                
                                headerCells.forEach(function(cell) {
                                    cell.style.width = newWidth + 'px';
                                    cell.style.minWidth = newWidth + 'px';
                                    cell.style.maxWidth = newWidth + 'px';
                                });
                                
                                dataCells.forEach(function(cell) {
                                    cell.style.width = newWidth + 'px';
                                    cell.style.minWidth = newWidth + 'px';
                                    cell.style.maxWidth = newWidth + 'px';
                                });
                                
                                const newHandleLeft = startHandleLeft + diff;
                                newHandle.style.left = (newHandleLeft - 2) + 'px';
                                
                                const allHandles = Array.from(tableContainer.querySelectorAll('.resize-handle-collection'));
                                const currentIndex = allHandles.indexOf(newHandle);
                                const allHeaders = Array.from(tableContainer.querySelectorAll('[data-column-header]'));
                                
                                let cumulativeWidth = 0;
                                allHeaders.forEach(function(headerCell) {
                                    const key = headerCell.getAttribute('data-column-header');
                                    let width = (key === columnKey) ? newWidth : parseInt(window.getComputedStyle(headerCell).width, 10);
                                    cumulativeWidth += width;
                                    
                                    const handleForColumn = allHandles.find(function(h) {
                                        return h.getAttribute('data-column-key') === key;
                                    });
                                    
                                    if (handleForColumn && allHandles.indexOf(handleForColumn) > currentIndex) {
                                        handleForColumn.style.left = (cumulativeWidth - 2) + 'px';
                                    }
                                });
                            }
                            
                            function onMouseUp(e) {
                                const diff = e.clientX - startX;
                                const newWidth = Math.max(50, startWidth + diff);
                                
                                const input = document.getElementById('column-resize-input-collection');
                                if (input) {
                                    input.value = columnKey + ':' + newWidth;
                                    const event = new Event('change', { bubbles: true });
                                    input.dispatchEvent(event);
                                }
                                
                                document.removeEventListener('mousemove', onMouseMove);
                                document.removeEventListener('mouseup', onMouseUp);
                                document.body.style.cursor = '';
                                document.body.style.userSelect = '';
                            }
                            
                            document.body.style.cursor = 'col-resize';
                            document.body.style.userSelect = 'none';
                            document.addEventListener('mousemove', onMouseMove);
                            document.addEventListener('mouseup', onMouseUp);
                        });
                    });
                };
                
                if (document.readyState === 'loading') {
                    document.addEventListener('DOMContentLoaded', function() {
                        setTimeout(window.initColumnResizecolumn_resize_input_collection, 100);
                    });
                } else {
                    setTimeout(window.initColumnResizecolumn_resize_input_collection, 100);
                }
                
                const observer = new MutationObserver(function() {
                    setTimeout(window.initColumnResizecolumn_resize_input_collection, 150);
                });
                observer.observe(document.body, { childList: true, subtree: true });
                `),o(`div`,{className:`flex border-b border-gray-700 group relative`,css:{backgroundColor:`rgb(23, 23, 25)`}},o(O,{}),o(v,{}),o(w,{}),o(A,{}),o(m,{}),o(k,{})),o(`div`,{className:`absolute inset-0`,css:{zIndex:50,pointerEvents:`none`}},o(x,{}),o(g,{}),o(D,{}),o(j,{}),o(h,{})),o(b,{}))))))}function I(){return o(N.Fragment,{},r((0,N.useContext)(i.reflex___state____state__app___states___collections____collections_state).active_collection_rx_state_)?o(N.Fragment,{},o(`div`,{},o(F,{}))):o(N.Fragment,{},o(`div`,{className:`flex items-center justify-center py-12`},o(`span`,{className:`text-gray-400 text-sm`},`No collection selected. Select a collection to get started.`))))}function L(){return o(N.Fragment,{},(0,N.useContext)(i.reflex___state____state__app___states___workspace____workspace_state).is_entity_route_rx_state_?o(l,{}):o(I,{}))}function R(){return o(N.Fragment,{},(0,N.useContext)(i.reflex___state____state__app___states___workspace____workspace_state).is_menu_route_rx_state_?o(N.Fragment,{},o(`div`,{className:`flex items-center justify-center py-12`},o(d,{}))):o(L,{}))}var z=n(function(){return o(N.Fragment,{},o(`div`,{className:`flex font-['Inter']`,css:{backgroundColor:`rgb(16, 16, 18)`}},o(E,{}),o(`div`,{className:`flex-1 h-screen overflow-y-auto`,css:{backgroundColor:`rgb(23, 23, 25)`}},o(`div`,{className:`flex items-center px-6 pt-6 pb-4`},o(c,{}),o(C,{})),o(`div`,{className:`px-6 pb-6`},o(R,{}))),o(`div`,{},o(u,{})),o(f,{})),o(`title`,{},`App | Collections`),o(`meta`,{content:`favicon.ico`,property:`og:image`}))});export{z as default};